var GitHubDiffSettings = { 
	defaults: {
	    additionGutter: '90EE90',
	    additionCode: '00FF00',
	    deletionGutter: 'FFECEC',
	    deletionCode: 'FFDDDD'
	},
	settingsKey: 'diffsettings'
};